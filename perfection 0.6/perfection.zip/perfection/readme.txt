
* Finished *
- 404.php
- archive.php
- single.php

* To do *
